The files contained in this folder should be installed in the 'converters' folder within your installation.

Please see the help for details.
