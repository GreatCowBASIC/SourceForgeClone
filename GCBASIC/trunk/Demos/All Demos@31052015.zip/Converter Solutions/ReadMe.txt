The files contained in the 'converters' folder MUST be installed in the 'converters' folder within your installation.

Please see the help for details.
