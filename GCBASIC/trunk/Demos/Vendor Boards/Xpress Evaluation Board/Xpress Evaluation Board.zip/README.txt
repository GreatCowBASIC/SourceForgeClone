Compiled using the Great Cow BASIC compiler.

These demonstrations all operate the Serial Terminal at 19200 BPS.

