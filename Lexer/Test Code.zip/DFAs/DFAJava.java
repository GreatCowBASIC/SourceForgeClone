import java.util.Scanner;
import java.util.ArrayList;
import java.io.*;

class DFAJava{
	
	//Data extracted from .jff file
	private ArrayList<String> states = new ArrayList<String>();
	private ArrayList<Transition> transitions = new ArrayList<Transition>();
	private ArrayList<String> acceptStates = new ArrayList<String>();
	private int firstState = 0; //Initial state
	
	//Arraylist to store output code
	private ArrayList<String> output = new ArrayList<String>();
	
	//Name of output class/file
	private String outClass;
	private String outSub;
	private boolean testRoutine = true;
	
	//Output language
	enum OutLang{
		BASIC,
		Java
	}
	OutLang outLang;
	
	//Input file
	private String inFile;
	
	private boolean loadData(String dataFile){
		inFile = dataFile;
		
		//Load data from file		
		try {
			BufferedReader input = new BufferedReader (new FileReader(dataFile));
			boolean inTrans = false;
			boolean inState = false;
			int lastState = 0; //Last state read
			int from = 0;
			int to = 0;
			String changeOn = "\0";
			
			String inLine = input.readLine();
			while (inLine != null) {
				
				if (inLine.indexOf("<type>") != -1 && inLine.indexOf("fa") == -1){
					System.out.println ("Sorry, this program only works with DFAs!");
					input.close();
					return false;
				
				}else if (inLine.indexOf("<state id=") != -1) {
					inState = true;
					String tempValue = inLine.substring(inLine.indexOf("id=\"") + 4);
					tempValue = tempValue.substring(0, tempValue.indexOf('\"')).trim();
					lastState = Integer.parseInt(tempValue);
					states.add(String.valueOf(lastState));
					
				}else if (inLine.indexOf("</state>") != -1) {
					inState = false;
				
				}else if (inLine.indexOf("<transition>") != -1){
					inTrans = true;
				}else if (inLine.indexOf("</transition>") != -1){
					transitions.add(new Transition(from, to, changeOn));
					inTrans = false;
				
				}else if (inTrans){
					String tempValue = inLine.substring(inLine.indexOf('>') + 1);
					tempValue = tempValue.substring(0, tempValue.indexOf('<'));
					
					if (inLine.indexOf("<from>") != -1) from = Integer.parseInt(tempValue.trim());
					if (inLine.indexOf("<to>") != -1) to = Integer.parseInt(tempValue.trim());
					if (inLine.indexOf("<read>") != -1){
						changeOn = tempValue.replace("&gt;", ">").
						                     replace("&lt;", "<").
											 replace("&amp;", "&");
					}
						
				}else if (inState){
					if (inLine.indexOf("<initial/>") != -1) firstState = lastState;
					if (inLine.indexOf("<final/>") != -1) acceptStates.add(String.valueOf(lastState));
				}
				
				inLine = input.readLine();
			}
			
			input.close();
			return true;
			
		} catch (java.io.FileNotFoundException e) {
			System.out.println ("File not found: " + dataFile);
			return false;
		} catch (java.io.IOException e) {
			System.out.println ("A file IO error occurred");
			return false;
		}
	}
	
	private boolean translate(){
		
		if (outLang == OutLang.Java){
			//Start of class
			output.add(new String("//Automatically generated from " + inFile));
			output.add(new String("class " + outClass + "{"));
			output.add(new String("\t"));
			
			//input data members
			output.add(new String("\tprivate String inData;"));
			output.add(new String("\tprivate int inPos;"));
			output.add(new String("\t"));
		
			//constructor
			output.add(new String("\tpublic " + outClass + "(String inData){"));
			output.add(new String("\t\tthis.inData = inData;"));
			output.add(new String("\t}"));
			output.add(new String("\t"));
			
			//character pop
			output.add(new String("\tprivate char pop(){"));
			output.add(new String("\t\tchar c;"));
			output.add(new String("\t\tif (inData.length() > inPos){"));
			output.add(new String("\t\t\tc = inData.charAt(inPos ++);"));
			output.add(new String("\t\t} else {"));
			output.add(new String("\t\t\tc = 0;"));
			output.add(new String("\t\t}"));
			output.add(new String("\t\treturn c;"));
			output.add(new String("\t}"));
			output.add(new String("\t"));
			
			//character peek
			output.add(new String("\tprivate char peek(){"));
			output.add(new String("\t\tchar c;"));
			output.add(new String("\t\tif (inData.length() > inPos){"));
			output.add(new String("\t\t\tc = inData.charAt(inPos);"));
			output.add(new String("\t\t} else {"));
			output.add(new String("\t\t\tc = 0;"));
			output.add(new String("\t\t}"));
			output.add(new String("\t\treturn c;"));
			output.add(new String("\t}"));
			output.add(new String("\t"));
			
			//String pop
			output.add(new String("\tprivate String pop(int charCount){"));
			output.add(new String("\t\tString s;"));
			output.add(new String("\t\tif (inData.length() > inPos){"));
			output.add(new String("\t\t\ttry {"));
			output.add(new String("\t\t\t\ts = inData.substring(inPos, inPos + charCount);"));
			output.add(new String("\t\t\t\tinPos += charCount;"));
			output.add(new String("\t\t\t} catch (StringIndexOutOfBoundsException e){"));
			output.add(new String("\t\t\t\ts = \"\";"));
			output.add(new String("\t\t\t}"));
			output.add(new String("\t\t} else {"));
			output.add(new String("\t\t\ts = \"\";"));
			output.add(new String("\t\t}"));
			output.add(new String("\t\treturn s;"));
			output.add(new String("\t}"));
			output.add(new String("\t"));
			
			//String peek
			output.add(new String("\tprivate String peek(int charCount){"));
			output.add(new String("\t\tString s;"));
			output.add(new String("\t\tif (inData.length() > inPos){"));
			output.add(new String("\t\t\ttry {"));
			output.add(new String("\t\t\t\ts = inData.substring(inPos, inPos + charCount);"));
			output.add(new String("\t\t\t} catch (StringIndexOutOfBoundsException e){"));
			output.add(new String("\t\t\t\ts = \"\";"));
			output.add(new String("\t\t\t}"));
			output.add(new String("\t\t} else {"));
			output.add(new String("\t\t\ts = \"\";"));
			output.add(new String("\t\t}"));
			output.add(new String("\t\treturn s;"));
			output.add(new String("\t}"));
			output.add(new String("\t"));
			
			//runDFA method
			output.add(new String("\tpublic boolean runDFA(){"));
			output.add(new String("\t\t"));
			output.add(new String("\t\tif (testDFA() == 0){"));
			output.add(new String("\t\t\treturn true;"));
			output.add(new String("\t\t} else {"));
			output.add(new String("\t\t\treturn false;"));
			output.add(new String("\t\t}"));
			output.add(new String("\t}"));
			output.add(new String("\t"));
			
			//testDFA method
			output.add(new String("\t/*"));
			output.add(new String("\t  testDFA() returns one of the following"));
			output.add(new String("\t    0: input accepted"));
			output.add(new String("\t    1: input rejected after reaching end of string"));
			output.add(new String("\t    2: input rejected after reaching a state without any further valid transitions"));
			output.add(new String("\t*/"));
			output.add(new String("\tpublic int testDFA(){"));
			output.add(new String("\t"));
			output.add(new String("\t\tboolean getNext = false;"));
			output.add(new String("\t\tint state = " + String.valueOf(firstState) + ";"));
			output.add(new String("\t\t"));
			
			output.add(new String("\t\tchar inChar = peek();"));
			output.add(new String("\t\twhile (inChar != 0) {"));
			output.add(new String("\t\t\tgetNext = false;"));
			output.add(new String("\t\t\t"));
			
			for (String state: states){
				output.add(new String("\t\t\t//State " + state));
				output.add(new String("\t\t\tif (!getNext && state == " + state + ") {"));
				
				boolean hasDefault = false;
				int defaultTo = 0;
				
				for (Transition t: transitions){
					if (t.fromState == Integer.parseInt(state)){
						
						//Standard inputs
						if (t.changeOn.charAt(0) != '~' || t.changeOn.length() == 1){
							//Single char
							if (t.changeOn.length() == 1){
								String temp = new String(t.changeOn);
								if (temp.equals("\"")) temp = "\\\"";
								if (temp.equals("\'")) temp = "\\\'";
								if (temp.equals("\\")) temp = "\\\\";
								
								output.add(new String("\t\t\t\tif (inChar == '" + temp + "'){"));
								output.add(new String("\t\t\t\t\tpop();"));
								output.add(new String("\t\t\t\t\tgetNext = true;"));
								output.add(new String("\t\t\t\t\tstate = " + String.valueOf(t.toState) + ";"));
								output.add(new String("\t\t\t\t}"));
							//String
							} else {
								output.add(new String("\t\t\t\tif (peek(" + String.valueOf(t.changeOn.length()) + ").equals(\"" + t.changeOn + "\")){"));
								output.add(new String("\t\t\t\t\tpop(" + String.valueOf(t.changeOn.length()) + ");"));
								output.add(new String("\t\t\t\t\tgetNext = true;"));
								output.add(new String("\t\t\t\t\tstate = " + String.valueOf(t.toState) + ";"));
								output.add(new String("\t\t\t\t}"));
							}
						//Special wildcard inputs
						} else {
							switch (t.changeOn.charAt(1)){
								//any letter
								case 'l':
									output.add(new String("\t\t\t\tif (Character.isLetter(inChar)){"));
									output.add(new String("\t\t\t\t\tpop();"));
									output.add(new String("\t\t\t\t\tgetNext = true;"));
									output.add(new String("\t\t\t\t\tstate = " + String.valueOf(t.toState) + ";"));
									output.add(new String("\t\t\t\t}"));
									break;
								
								//any digit
								case 'd':
									output.add(new String("\t\t\t\tif (Character.isDigit(inChar)){"));
									output.add(new String("\t\t\t\t\tpop();"));
									output.add(new String("\t\t\t\t\tgetNext = true;"));
									output.add(new String("\t\t\t\t\tstate = " + String.valueOf(t.toState) + ";"));
									output.add(new String("\t\t\t\t}"));
									break;
								
								//anything in range (inclusive)
								case 'r':
									char startRange = t.changeOn.charAt(2);
									char endRange = t.changeOn.charAt(3);
									output.add(new String("\t\t\t\tif (inChar >= '" + startRange + "' && inChar <= '" + endRange + "'){"));
									output.add(new String("\t\t\t\t\tpop();"));
									output.add(new String("\t\t\t\t\tgetNext = true;"));
									output.add(new String("\t\t\t\t\tstate = " + String.valueOf(t.toState) + ";"));
									output.add(new String("\t\t\t\t}"));
									break;
								
								//else (anything not already detected)
								case 'e':
									hasDefault = true;
									defaultTo = t.toState;
							}
						}
					}
				}
				
				//Default
				if (hasDefault){
					output.add(new String("\t\t\t\tif (!getNext){"));
					output.add(new String("\t\t\t\t\tpop();"));
					output.add(new String("\t\t\t\t\tgetNext = true;"));
					output.add(new String("\t\t\t\t\tstate = " + String.valueOf(defaultTo) + ";"));
					output.add(new String("\t\t\t\t}"));
				}
				
				output.add(new String("\t\t\t}"));
				output.add(new String("\t\t\t"));
				
			}
			
			output.add(new String("\t\t\t//Catch any rejections"));
			output.add(new String("\t\t\tif (!getNext && peek() != 0){"));
			output.add(new String("\t\t\t\t//Reached end of DFA, return false;"));
			output.add(new String("\t\t\t\treturn 2;"));
			output.add(new String("\t\t\t}"));
			output.add(new String("\t\t\t"));
			output.add(new String("\t\t\tinChar = peek();"));
			output.add(new String("\t\t}"));
			output.add(new String("\t\t"));
			
			output.add(new String("\t\t//Accept states"));
			for (String acceptState: acceptStates){
				output.add(new String("\t\tif (state == " + acceptState + ") return 0;"));
			}
			
			output.add(new String("\t\t"));
			output.add(new String("\t\t//Reached end of input, return false"));
			output.add(new String("\t\treturn 1;"));
			output.add(new String("\t}"));
			output.add(new String("\t"));
			
			//main method
			output.add(new String("\tpublic static void main(String[] args){"));
			output.add(new String("\t\t"));
			output.add(new String("\t\tString testValue = args[0];"));
			output.add(new String("\t\t" + outClass + " myDFA = new " + outClass + "(testValue);"));
			output.add(new String("\t\t"));
			output.add(new String("\t\tSystem.out.println(testValue);"));
			output.add(new String("\t\tif (myDFA.runDFA()) {"));
			output.add(new String("\t\t\tSystem.out.println(\"Accept\");"));
			output.add(new String("\t\t} else {"));
			output.add(new String("\t\t\tSystem.out.println(\"Reject\");"));
			output.add(new String("\t\t}"));
			output.add(new String("\t\t"));
			output.add(new String("\t}"));
		
			//End of class
			output.add(new String("\t"));
			output.add(new String("}"));
			
		} else if (outLang == OutLang.BASIC){
			output.add(new String("\'Automatically generated from " + inFile));
			
			//TestDFA subroutine
			output.add(new String(""));
			output.add(new String("\'Test" + outSub + " returns:"));
			output.add(new String("\'  0 if input accepted"));
			output.add(new String("\'  1 if input rejected after reaching end of string"));
			output.add(new String("\'  2 if input rejected after reaching a state without any further valid transitions"));
			output.add(new String("Function Test" + outSub + " (InData As String, ByRef State As Integer = " + String.valueOf(firstState) + ", ByRef InputStart As Integer = 1) As Integer"));
			output.add(new String("\tDim InChar As String"));
			//output.add(new String("\tDim As Integer State, InputStart, InCharVal"));
			output.add(new String("\tDim As Integer InCharVal"));
			output.add(new String("\t"));
			
			output.add(new String("\tIf State = -1 Then State = " + String.valueOf(firstState)));
			//output.add(new String("\tState = " + String.valueOf(firstState)));
			//output.add(new String("\tInputStart = 1"));
			//output.add(new String("\tInChar = \"\""));
			//output.add(new String("\tInCharVal = 0"));
			//output.add(new String("\t"));
			
			output.add(new String("\tDo While InputStart <= Len(InData)"));
			output.add(new String("\t\tInChar = MID(InData, InputStart, 1)"));
			output.add(new String("\t\tInCharVal = Asc(InChar)"));
			output.add(new String("\t\t"));
			
			for (String state: states){
				
				boolean hasDefault = false;
				boolean firstEntry = true;
				int defaultTo = 0;
				
				for (Transition t: transitions){
					if (t.fromState == Integer.parseInt(state)){
						
						//If at start of state
						if (firstEntry){
							output.add(new String("\t\t\'State " + state));
							output.add(new String("\t\tIf State = " + state + " Then"));
							firstEntry = false;
						}
						
						//Standard inputs
						if (t.changeOn.charAt(0) != '~' || t.changeOn.length() == 1){
							//Single char
							if (t.changeOn.length() == 1){
								String temp = new String(t.changeOn);
								output.add(new String("\t\t\t'" + temp));
								if (temp.equals("\"")) {
									temp = "34";
								} else {
									temp = Integer.toString((int)temp.charAt(0));
								}
								output.add(new String("\t\t\tIf InCharVal = " + temp + " Then"));
								output.add(new String("\t\t\t\tInputStart += 1"));
								output.add(new String("\t\t\t\tState = " + String.valueOf(t.toState)));
								output.add(new String("\t\t\t\tGoto GetNext"));
								output.add(new String("\t\t\tEnd If"));
								
							//String
							} else {
								output.add(new String("\t\t\tIf Mid(InData, InputStart, " + String.valueOf(t.changeOn.length()) + ") = \"" + t.changeOn + "\" Then"));
								output.add(new String("\t\t\t\tInputStart += " + String.valueOf(t.changeOn.length()) ));
								output.add(new String("\t\t\t\tState = " + String.valueOf(t.toState)));
								output.add(new String("\t\t\t\tGoto GetNext"));
								output.add(new String("\t\t\tEnd If"));
							}
						//Special wildcard inputs
						} else {
							int startRange, endRange;
							switch (t.changeOn.charAt(1)){
								//any letter
								case 'l':
									startRange = 'a';
									endRange = 'z';
									output.add(new String("\t\t\tIf Asc(LCase(InChar)) >= " + startRange + " And Asc(LCase(InChar)) <= " + endRange + " Then"));
									output.add(new String("\t\t\t\tInputStart += 1"));
									output.add(new String("\t\t\t\tState = " + String.valueOf(t.toState)));
									output.add(new String("\t\t\t\tGoto GetNext"));
									output.add(new String("\t\t\tEnd If"));
									break;
								
								//any digit
								case 'd':
									startRange = '0';
									endRange = '9';
									output.add(new String("\t\t\tIf InCharVal >= " + startRange + " And InCharVal <= " + endRange + " Then"));
									output.add(new String("\t\t\t\tInputStart += 1"));
									output.add(new String("\t\t\t\tState = " + String.valueOf(t.toState)));
									output.add(new String("\t\t\t\tGoto GetNext"));
									output.add(new String("\t\t\tEnd If"));
									break;
								
								//anything in range (inclusive)
								case 'r':
									startRange = t.changeOn.charAt(2);
									endRange = t.changeOn.charAt(3);
									output.add(new String("\t\t\tIf InCharVal >= " + startRange + " And InCharVal <= " + endRange + " Then"));
									output.add(new String("\t\t\t\tInputStart += 1"));
									output.add(new String("\t\t\t\tState = " + String.valueOf(t.toState)));
									output.add(new String("\t\t\t\tGoto GetNext"));
									output.add(new String("\t\t\tEnd If"));
									break;
								
								//else (anything not already detected)
								case 'e':
									hasDefault = true;
									defaultTo = t.toState;
							}
						}
					}
				}
				//Default
				if (hasDefault){
					output.add(new String("\t\t\t"));
					output.add(new String("\t\t\tInputStart += 1"));
					output.add(new String("\t\t\tState = " + String.valueOf(defaultTo)));
					output.add(new String("\t\t\tGoto GetNext"));
				}
				
				if (!firstEntry){
					output.add(new String("\t\tEnd If"));
					output.add(new String("\t\t"));
				}
			}
			
			output.add(new String("\t\t\'Catch any rejections"));
			output.add(new String("\t\tReturn 2"));
			output.add(new String("\t\t"));
			output.add(new String("\t\tGetNext:"));
			output.add(new String("\tLoop"));
			output.add(new String("\t"));
			
			output.add(new String("\t\'Accept states"));
			for (String acceptState: acceptStates){
				output.add(new String("\tIf State = " + acceptState + " Then Return 0"));
			}
			output.add(new String("\t"));
			output.add(new String("\tReturn 1"));
			output.add(new String("\t"));
			output.add(new String("End Function"));
			output.add(new String(""));
			
			//RunDFA subroutine
			output.add(new String("Function Run" + outSub + " (InData As String) As Integer"));
			output.add(new String("\t"));
			output.add(new String("\tIf Test" + outSub + " (InData) = 0 Then"));
			output.add(new String("\t\tReturn -1"));
			output.add(new String("\tElse"));
			output.add(new String("\t\tReturn 0"));
			output.add(new String("\tEnd If"));
			output.add(new String("\t"));
			output.add(new String("End Function"));
			output.add(new String(""));
			
			//Test main routine
			if (testRoutine) {
				output.add(new String("'Main Routine (test)"));
				output.add(new String("Print \"Input:\" + COMMAND"));
				output.add(new String("If Run" + outSub + " (COMMAND) Then"));
				output.add(new String("\tPrint \"Accept\""));
				output.add(new String("Else"));
				output.add(new String("\tPrint \"Reject\""));
				output.add(new String("End If"));
				output.add(new String(""));
			}
			
		}
		
		return true;
	}
	
	private void writeOutput(){
		try {
			BufferedWriter writeOut;
			if (outLang == OutLang.Java) {
				writeOut = new BufferedWriter( new FileWriter(outClass + ".java"));
			} else if (outLang == OutLang.BASIC) {
				writeOut = new BufferedWriter( new FileWriter(outClass));
			} else {
				return;
			}
		
			//Write generated program
			for (String temp: output){
				writeOut.write(temp);
				writeOut.newLine();
			}
			
			writeOut.close();
			
		} catch (IOException e){
			System.out.println("A file IO error occurred while writing " + outClass + ".java");
		}
	}
	
	public static void main(String[] args){
		
		System.out.println ("JFLAP DFA > Java/BASIC converter");
		
		if (args.length == 0) {
			System.out.println ("Produces a Java class or FreeBASIC program from a JFLAP DFA");
			System.out.println ();
			System.out.println ("This program by Hugh Considine, 2007");
			System.out.println ();
			System.out.println ("Run using this command:");
			System.out.println ("java DFAJava infile [outfile]");
			System.out.println ("\tinfile      The input jff file to read");
			System.out.println ("\toutfile     File or class to create (optional, default is \"DFA\")");
			System.out.println ("\t            If outfile ends in .bas or .bi, a BASIC program will be produced");
			System.out.println ("\t            Otherwise, the output will be a Java class named outfile");
			System.out.println ();
			return;
		}
		
		DFAJava xlate = new DFAJava();
		
		if (args.length == 2){
			xlate.outClass = args[1];
		} else {
			xlate.outClass = "DFA";
		}
		
		xlate.outSub = "DFA";
		xlate.outLang = OutLang.Java;
		if (xlate.outClass.toLowerCase().indexOf(".bas") != -1){
			xlate.outLang = OutLang.BASIC;
			xlate.outSub = xlate.outClass.substring(0, xlate.outClass.toLowerCase().lastIndexOf(".bas"));
			xlate.testRoutine = true;
		} else if (xlate.outClass.toLowerCase().indexOf(".bi") != -1){
			xlate.outLang = OutLang.BASIC;
			xlate.outSub = xlate.outClass.substring(0, xlate.outClass.toLowerCase().lastIndexOf(".bi"));
			xlate.testRoutine = false;
		}
		
		System.out.println ("Loading .jff");
		if (xlate.loadData(args[0])){
			if (xlate.outLang == OutLang.Java) {
				System.out.println ("Translating to Java");
			} else {
				System.out.println ("Translating to BASIC");
			}
			if (xlate.translate()){
				if (xlate.outLang == OutLang.Java) {
					System.out.println ("Writing output to " + xlate.outClass + ".java");
				} else {
					System.out.println ("Writing output to " + xlate.outClass);
				}
				xlate.writeOutput();
			}
		} else {
			return;
		}
		
	}
	
}