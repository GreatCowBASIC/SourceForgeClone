class Transition{
	
	public Transition (int fromState, int toState, String changeOn){
		this.fromState = fromState;
		this.toState = toState;
		this.changeOn = changeOn;
	}
	
	public int fromState;
	public int toState;
	public String changeOn;
	
}