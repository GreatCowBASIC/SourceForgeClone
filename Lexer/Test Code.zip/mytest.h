'General hardware configuration

'#chip 16F877A,20

'#chip 18F4550, 48
'#config FOSC=HSPLL_HS, PLLDIV=5, CPUDIV=OSC1_PLL2

#chip 18F4620, 20

'#chip 16F690, 20
'#config osc=int

'LCD connection settings
#define LCD_IO 4

'#define LCD_DATA_PORT PORTC

'20 pin settings
'#define LCD_DB4 PORTB.6
'#define LCD_DB5 PORTB.5
'#define LCD_DB6 PORTB.4
'#define LCD_DB7 PORTC.2
'#define LCD_RS PORTC.6
'#define LCD_RW PORTC.7
'#define LCD_Enable PORTB.7

'40 pin settings
#define LCD_DB4 PORTD.4
#define LCD_DB5 PORTD.5
#define LCD_DB6 PORTD.6
#define LCD_DB7 PORTD.7
#define LCD_RS PORTD.0 
#define LCD_RW PORTD.1
#define LCD_Enable PORTD.2

