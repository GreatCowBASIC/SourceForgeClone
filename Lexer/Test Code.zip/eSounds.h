'Annoying noises for eVil uses
'Suitable for 4 and 20 Mhz chips, others may need adjustments to the code to work properly

Sub Bell
	Repeat 3
		For RepeatLevel = 25 to 1
			Repeat 20
				PulseOut SoundOut, RepeatLevel 10us
				Wait 114 - RepeatLevel 10us
			End Repeat
		Next
		Wait 250 ms
	End Repeat
End Sub

Sub Bomb
	'Falling
	For WaveLen = 50 to 100
		For RepeatLevel = 1 To 50
			PulseOut SoundOut, 10 10us
			Wait WaveLen 10us
		Next
	Next
	
	'Pop!
	For WaveLen = 100 to 20
		PulseOut SoundOut, 10 10us
		Wait WaveLen 10us
	Next
End Sub

Sub HighBeep
	'15 KHz beep
	'Period = 67 us
	Repeat 50000
		PulseOut SoundOut, 1 10us
		#IFNDEF ChipMHz 4
			Wait 55 us
		#ENDIF
		'Need lesser delay on slower chips, as other instructions take too long
		#IFDEF ChipMHz 4
			Wait 47 us
		#ENDIF
	End Repeat
End Sub

Sub LEDFun
	Pip
	For Temp = 1 to 30
		ShortPip
	Next
End Sub

Sub MainsBuzz
	'50 Hz mains buzz
	Repeat 75
		Pulseout SoundOut, 10 ms
		Wait 10 ms
	End Repeat
End Sub

Sub Mosquito
	For Volume = 1 to 40
		NoiseOut Volume
	Next
	For Volume = 40 to 1
		NoiseOut Volume
	Next
End Sub

Sub Project10
	#IFDEF NotBuzzer
		Repeat 5
			DelLen = 0
			Repeat 13
				DelLen += 1
				Repeat DelLen
					'Frequency 2500 Hz
					'Period 0.4 ms
					Repeat 4
						PulseOut SoundOut, 15 10us
						Wait 25 10us
					End Repeat
					'Wait 154 10us
				End Repeat
				
				DelLen += 1
				Repeat DelLen
					Wait 154 10us
				End Repeat
			End Repeat
		End Repeat
	#ENDIF
	#IFNDEF NotBuzzer
		Repeat 5
			DelLen = 0
			Repeat 13
				Set SoundOut On
				DelLen += 1
				Repeat DelLen
					Wait 154 10us
				End Repeat
				
				Set SoundOut Off
				DelLen += 1
				Repeat DelLen
					Wait 154 10us
				End Repeat
			End Repeat
		End Repeat
	#ENDIF
End Sub

Sub SmokeAlarm
	Repeat 10
		'3200 Hz
		'0.31  ms period
		Repeat 323
			PulseOut SoundOut, 11 10us
			Wait 20 10us
		End Repeat
		Wait 100 ms
	End Repeat
End Sub

Sub SMS
	Repeat 2
		Repeat 2
			Repeat 343
				'Total time through here: 694 us
				'259 us pulse
				Pulseout SoundOut, 129 us
				Wait 130 us
				
				'435 us pulse
				PulseOut SoundOut, 200 us
				Wait 235 us
			End Repeat
			Wait 40 ms
		End Repeat
		Wait 700 ms
	End Repeat
End Sub

Sub TicketFail
	
	'Noise of ticket going in
	Repeat 2
		'210 ms noise
		'1000 KHz = 1 ms
		'1428 KHz = 0.7 ms
		'2000 KHz = 0.5 ms
		'2500 KHz = 0.4 ms
		
		Repeat 81
			'1000
			PulseOut SoundOut, 2 10us
			Wait 98 10us
			'2500
			PulseOut SoundOut, 2 10us
			Wait 38 10us
			'1428
			PulseOut SoundOut, 2 10us
			Wait 68 10us
			'2000
			PulseOut SoundOut, 2 10us
			Wait 48 10us
		End Repeat
		
		'6 ms silence
		Wait 6 ms
	End Repeat
	
	Wait 20 ms
	
	'Fail noise
	Repeat 3
		'87 ms beep
		'Period 2.31 ms
		'Rise in 27
		For MakeNoise = 4 to 48 Step 4
			PulseOut SoundOut, MakeNoise 10us
			Wait 231 - MakeNoise 10us
		Next
		'Hold 33 ms
		Repeat 14
			PulseOut SoundOut, 50 10us
			Wait 181 10us
		End Repeat
		'Fall in 27
		For MakeNoise = 48 to 4 Step -4
			PulseOut SoundOut, MakeNoise 10us
			Wait 231 - MakeNoise 10us
		Next
		
		'48 ms silence
		Wait 48 ms
		
	End Repeat
	
End Sub

Sub WolfWhistle
	'Frequency is 1565 Hz, period 639 us
	
	'Rising
	'Rise: 50 ms to half volume
	For Level = 1 to 16
		Repeat 5
			PulseOut SoundOut, Level 10us
			Wait 64 - Level 10us
		End Repeat
	Next
	'Rise, 214 ms to full volume
	For Level = 16 to 32
		Repeat 21
			PulseOut SoundOut, Level 10us
			Wait 64 - Level 10us
		End Repeat
	Next
	'Fall, 52 ms to silence
	For Level = 32 to 1
		Repeat 2
			PulseOut SoundOut, Level 10us
			Wait 64 - Level 10us
		End Repeat
	Next
	
	'Pause
	Wait 350 ms
	
	'Trail off
	'Rise, 88 ms to full
	For Level = 1 To 32
		Repeat 4
			PulseOut SoundOut, Level 10us
			Wait 64 - Level 10us
		End Repeat
	Next
	'Fall, 293 ms to 1/4 volume
	For Level = 32 to 8
		Repeat 19
			PulseOut SoundOut, Level 10us
			Wait 64 - Level 10us
		End Repeat
	Next
	'Hold, 342 ms at 1/4
	Repeat 535
		PulseOut SoundOut, 8 10us
		Wait 56 10us
	End Repeat
	'Fall, 82 ms to silence
	For Level = 8 to 1
		Repeat 16
			PulseOut SoundOut, Level 10us
			Wait 64 - Level 10us
		End Repeat
	Next
	
End Sub

Sub Pip

	'3 tine pip / Good sound...
	'1329hz for 0.25 s
	'376 us between on and off, repeat 332 times
	Repeat 332
		PulseOut Soundout, 376 us
		Wait 376 us
	End Repeat
	
	'2664 hz for 0.2 s
	'187 us between on and off, repeat 535 times
	Repeat 535
		PulseOut Soundout, 187 us
		Wait 187 us
	End Repeat
	
	'661hz for 0.22 s
	'756 us between on and off, repeat 145 times
	Repeat 145
		PulseOut Soundout, 756 us
		Wait 756 us
	End Repeat
End Sub

sub ShortPip
	
	'Starting value = 9952 us
	LoopCount = 1
	BeepLen = 32
	For MakeNoise = 1 to 6
		Repeat LoopCount
			Set SoundOut On
			Repeat BeepLen
				Wait 155 us
			End Repeat
			Set SoundOut Off
			Repeat BeepLen
				Wait 155 us
			End Repeat
		End Repeat
		LoopCount = LoopCount * 2
		BeepLen = BeepLen / 2
	Next
End Sub

Sub NoiseOut (In VolumeLevel)
	#IFNDEF ChipMhz 4, 8
	For Temp = 1 to 30
	    PulseOut SoundOut, VolumeLevel us
		Wait 1 ms
	Next
	#ENDIF
	#IFDEF ChipMhz 4, 8
	rrf VolumeLevel, F
	rrf VolumeLevel, F
	rrf VolumeLevel, W
	andlw 31
	btfsc STATUS, Z
	addlw 1
	movwf VolumeLevel
	Repeat 30
	    PulseOut SoundOut, VolumeLevel 10us
		Wait 1 ms
	End Repeat
	#ENDIF
End Sub
