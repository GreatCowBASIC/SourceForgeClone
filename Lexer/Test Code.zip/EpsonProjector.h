'Routine/s to control Epson projectors
'Based on data from http://lirc.sourceforge.net/remotes/epson/12807990

'Commands
#define epPageUp 0x61
#define epPageDown 0xE1
#define epZoomIn 0x11
#define epZoomOut 0x91
#define epUp 0x0D
#define epDown 0x4D
#define epLeft 0xCD
#define epRight 0x8D
#define epPower 0x09
#define epEnter 0xA1
#define epEsc 0x21
#define ep1 0xE9
#define ep2 0x69
#define ep3 0x51
#define ep4 0x29
#define ep5 0xA9
#define ep6 0xF1
#define ep7 0xD9
#define ep8 0xC9
#define ep9 0x49
#define ep0 0x79
#define epSearch 0x31
#define epVolDown 0x99
#define epVolUp 0x19
#define epHelp 0xF9
#define epMenu 0x59

#define epAddress 0xC1AA

Sub epSendRemote(In Address As Word, In RemoteCommand)
	
	'Start bit
	PWMOn
	Wait 9 ms
	PWMOff
	Wait 4 ms
	Wait 50 10us
	
	'Address
	For Temp = 1 To 16
		PWMOn
		Wait 59 10us
		PWMOff
		If Address.15 Then
			Wait 165 10us
		Else
			Wait 50 10us
		End If
		Rotate Address left
	Next
	
	'Command
	Command = RemoteCommand
	For Temp = 1 to 8
		PWMOn
		Wait 59 10us
		PWMOff
		If Command.7 Then
			Wait 165 10us
		Else
			Wait 50 10us
		End If
		Rotate Command left
	Next
	
	'Command complement
	Command = RemoteCommand
	For Temp = 1 to 8
		PWMOn
		Wait 59 10us
		PWMOff
		If Command.7 Then
			Wait 50 10us
		Else
			Wait 165 10us
		End If
		Rotate Command left
	Next
	
	'Final IR burst
	PWMOn
	Wait 59 10us
	PWMOff
	
End Sub
